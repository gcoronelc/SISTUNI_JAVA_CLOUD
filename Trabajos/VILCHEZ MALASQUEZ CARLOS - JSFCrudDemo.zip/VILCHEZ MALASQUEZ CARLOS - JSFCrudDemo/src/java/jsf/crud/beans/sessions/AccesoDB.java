/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.crud.beans.sessions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Carlos
 */
public final class AccesoDB {

  private AccesoDB() {
  }

  /**
   * Permite obtener un objeto Connection.
   * 
   * @return Retorna un objeto Connection con la conexión establecida a la base de datos.
   * @throws SQLException Si se produce error lanza un SQLException con el mensaje respectivo.
   */
  public final static Connection getConnection() throws SQLException {
    // Objeto Connection
    Connection cn = null;
      Scanner scan;
      
      
    // Parametros para la conexión con JDBC
    String driver = "com.mysql.jdbc.Driver";
    String urlDB = "jdbc:oracle:thin:@localhost:1521:XE";
    String user = "prueba2";
    String pass = "admin";
    // Proceso
    try {
      // Cargar el driver
      Class.forName(driver).newInstance();
      // Realizar la conexión
      cn = DriverManager.getConnection(urlDB, user, pass);      
    } catch (ClassNotFoundException e) {
      throw new SQLException("No se ha encontrado el driver.");
    } catch (Exception e) {
      e.printStackTrace();
      throw new SQLException("No se tiene acceso al servidor.");
    }    
    // Retornar conexión
    return cn;
  }

    public static void main(String[] args) {
        AccesoDB ac = new AccesoDB();
    }
}

